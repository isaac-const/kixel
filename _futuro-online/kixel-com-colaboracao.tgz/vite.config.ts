import { defineConfig, type Plugin } from 'vite'
import fs from 'node:fs'
import { attachCollab, lanIps } from './server/collab.mjs'

// Recebe os resultados do teste de estresse (para medir no celular via adb) e grava em bench.log
const bench = (): Plugin => {
  const mw = (req: any, res: any) => {
    let b = ''
    req.on('data', (d: Buffer) => (b += d))
    req.on('end', () => { fs.appendFileSync('bench.log', b + '\n'); res.end('ok') })
  }
  return { name: 'bench', configureServer: s => void s.middlewares.use('/__bench', mw), configurePreviewServer: s => void s.middlewares.use('/__bench', mw) }
}
// Colaboração em tempo real: relé WebSocket na mesma porta (/__collab) e os endereços de rede para montar o link
const collab = (): Plugin => {
  const info = (_req: any, res: any) => { res.setHeader('content-type', 'application/json'); res.end(JSON.stringify({ ips: lanIps() })) }
  return {
    name: 'collab',
    configureServer: s => { if (s.httpServer) attachCollab(s.httpServer); s.middlewares.use('/__collab/info', info) },
    configurePreviewServer: s => { if (s.httpServer) attachCollab(s.httpServer); s.middlewares.use('/__collab/info', info) }
  }
}
export default defineConfig({ server: { host: true, port: 5190 }, preview: { port: 5191, host: true }, plugins: [bench(), collab()] })
